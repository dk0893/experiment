This documentation has been replaced by docs/maintaining.md. Please refer to the new file or read it online.
